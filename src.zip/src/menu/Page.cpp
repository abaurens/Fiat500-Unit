#include "Page.hpp"

Menu::Page::Page(const QString &name, Page *parent)
: Entry{ name, parent }, m_layout(new QVBoxLayout(this))
{
  m_layout->addStretch();

  if (parent)
    m_accessButton = new Button(name, *this, parent);
}

Menu::Page::Button::Button(const QString &text, Page &target, Page *parent)
  : Menu::Item{ text, parent }, m_target{ &target }, m_button{ new QPushButton(text) }
{
  m_layout->addWidget(m_button);

  setContentsMargins(0, 0, 0, 0);

  connect(
    m_button, &QPushButton::clicked,
    [this]{ if (m_target) emit clicked(*m_target); }
  );
}
