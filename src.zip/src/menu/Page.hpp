#pragma once

#include "menu/Menu.hpp"
#include "menu/Entry.hpp"
#include "menu/Item.hpp"

#include <QVBoxLayout>

#include <QGroupBox>
#include <QPushButton>
#include <QStackedWidget>

template<class T>
concept PageType = std::derived_from<T, Menu::Page>;

class Menu::Page : public Menu::Entry
{
  Q_OBJECT

  class Button;

public:
  Page(const QString &name, Page *parent = nullptr);
  virtual ~Page() = default;

  template<PageType Pge>
  Pge *addPage(const QString &name);

signals:
  void pageAdded(Menu::Page &page);
  void pageRequested(Menu::Page &page);

private:
  void addWidget(QWidget *widget)
  {
    m_layout->insertWidget(m_layout->count() - 1, widget);
  }

private:
  QVBoxLayout *m_layout;
  Button      *m_accessButton;
};

class Menu::Page::Button : public Menu::Item
{
  Q_OBJECT

public:
  Button(const QString &text, Menu::Page &target, Menu::Page *parent);

signals:
  void clicked(Menu::Page &page);

private:
  Menu::Page  *m_target;
  QPushButton *m_button;
};

template<PageType Pge>
Pge *Menu::Page::addPage(const QString &name)
{
  Pge *newPage = new Pge(name, this);

  addWidget(newPage->m_accessButton);

  connect(
    newPage->m_accessButton, &Button::clicked,
    root(), &Page::pageRequested
  );

  emit root()->pageAdded(*newPage);
  return newPage;
}

// Define the Menu::addPage<> template here because we need Menu::Page to be complete
template<class T>
Menu::Page *Menu::addPage(const QString &name)
{
  return m_root->addPage<T>(name);
}
